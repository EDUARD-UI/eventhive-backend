package com.eventhive.app.controllers;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.eventhive.app.dto.ApiResponse;
import com.eventhive.app.dto.response.CompraResponseDTO;
import com.eventhive.app.dto.PagedResponse;
import com.eventhive.app.dto.request.CompraRequestDTO;
import com.eventhive.app.dto.response.PagoPosicionamientoDTO;
import com.eventhive.app.service.ServiceCompra;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/compras")
@RequiredArgsConstructor
public class CompraApiController {

    private final ServiceCompra compraService;

    //CONSULTAS
    @GetMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<PagedResponse<CompraResponseDTO>>> listar(Pageable pageable) {
        Page<CompraResponseDTO> page = compraService.listarMisCompras(pageable);
        return ResponseEntity.ok(ApiResponse.ok("Compras obtenidas", new PagedResponse<>(
                page.getContent(), page.getNumber(), page.getSize(),
                page.getTotalElements(), page.getTotalPages())));
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CompraResponseDTO>> obtener(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.ok("Compra obtenida", compraService.obtenerPorId(id)));
    }

    //ACCIONES DE COMPRA
    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<CompraResponseDTO>> crear(
            @Valid @RequestBody CompraRequestDTO request) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.ok("Compra realizada", compraService.realizarCompra(request)));
    }

    @PostMapping("/eventos/{eventoId}/posicionamiento/pagos")
    @PreAuthorize("hasRole('REPRESENTANTE')")
    public ResponseEntity<ApiResponse<PagoPosicionamientoDTO>> registrarPagoPosicionamiento(
            @PathVariable Long eventoId, @RequestParam Long planId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Pago simulado registrado",
                compraService.registrarPagoPosicionamiento(eventoId, planId)));
    }

    @GetMapping("/posicionamiento/pagos/{pagoId}")
    @PreAuthorize("hasRole('REPRESENTANTE')")
    public ResponseEntity<ApiResponse<PagoPosicionamientoDTO>> obtenerPagoPosicionamiento(
            @PathVariable Long pagoId) {
        return ResponseEntity.ok(ApiResponse.ok("Estado del pago obtenido",
                compraService.obtenerPagoPosicionamiento(pagoId)));
    }

    @PatchMapping("/posicionamiento/pagos/{pagoId}/confirmar-simulado")
    @PreAuthorize("hasRole('REPRESENTANTE')")
    public ResponseEntity<ApiResponse<PagoPosicionamientoDTO>> confirmarPagoPosicionamientoSimulado(
            @PathVariable Long pagoId) {
        return ResponseEntity.ok(ApiResponse.ok("Pago simulado confirmado",
                compraService.confirmarPagoPosicionamientoSimulado(pagoId)));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ApiResponse<Void>> cancelar(@PathVariable Long id) {
        compraService.cancelarCompra(id);
        return ResponseEntity.ok(ApiResponse.ok("Compra cancelada"));
    }
}