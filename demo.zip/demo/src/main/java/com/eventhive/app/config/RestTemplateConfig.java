package com.eventhive.app.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration
public class RestTemplateConfig {

    // Bean reutilizable para llamadas HTTP externas (Supabase Storage)
    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}