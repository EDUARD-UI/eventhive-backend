package com.eventhive.app.service;

import com.eventhive.app.dto.response.CompraResponseDTO;
import com.eventhive.app.dto.response.ItemCompraDTO;
import com.eventhive.app.dto.response.PagoPosicionamientoDTO;
import com.eventhive.app.dto.request.CompraRequestDTO;
import com.eventhive.app.enums.EstadoCompra;
import com.eventhive.app.enums.EstadoEvento;
import com.eventhive.app.enums.EstadoOrganizacion;
import com.eventhive.app.enums.EstadoPosicionamiento;
import com.eventhive.app.exception.BusinessException;
import com.eventhive.app.exception.ResourceNotFoundException;
import com.eventhive.app.model.*;
import com.eventhive.app.repository.CompraRepository;
import com.eventhive.app.repository.EventoRepository;
import com.eventhive.app.repository.LocalidadRepository;
import com.eventhive.app.repository.PosicionamientoEventoRepository;
import com.eventhive.app.repository.PlanPromocionRepository;
import com.eventhive.app.repository.TiqueteRepository;
import com.eventhive.app.utils.AuthenticatedUserHelper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ServiceCompra {

    private final CompraRepository compraRepository;
    private final EventoRepository eventoRepository;
    private final LocalidadRepository localidadRepository;
    private final PosicionamientoEventoRepository posicionamientoEventoRepository;
    private final TiqueteRepository tiqueteRepository;
    private final PlanPromocionRepository planPromocionRepository;
    private final AuthenticatedUserHelper authHelper;
    private final ServiceNotification serviceNotification;
    private final ServiceMonetizacion serviceMonetizacion;
    private final ServiceCorreo serviceCorreo;
    private final ObjectProvider<ServiceCompra> self;

    private static final int MAX_BOLETAS_POR_COMPRA = 5;

    //CONSULTAS
    @Transactional(readOnly = true)
    public Page<CompraResponseDTO> listarMisCompras(Pageable pageable) {
        Usuario usuario = authHelper.usuarioAutenticado();
        return compraRepository
                .findByClienteIdConItems(usuario.getId(), pageable)
                .map(this::compraToDTO);
    }

    @Transactional(readOnly = true)
    public CompraResponseDTO obtenerPorId(Long id) {
        Usuario usuario = authHelper.usuarioAutenticado();
        Compra compra = buscarCompra(id);
        validarOwnership(compra, usuario);
        return compraToDTO(compra);
    }

    //OPERACIONES DE COMPRA
    @Transactional
    public CompraResponseDTO realizarCompra(CompraRequestDTO request) {
        validarRequest(request);

        Usuario usuario = authHelper.usuarioAutenticado();

        Optional<Compra> existente = compraRepository
                .findByClienteIdAndIdempotencyKey(usuario.getId(), request.getIdempotencyKey());
        if (existente.isPresent()) {
            return compraToDTO(existente.get());
        }

        try {
            Compra guardada = self.getObject().intentarCrearCompra(request, usuario);
            serviceNotification.notificarCompraConfirmada(guardada);
            return compraToDTO(guardada);
        } catch (DataIntegrityViolationException e) {
            return compraRepository.findByClienteIdAndIdempotencyKey(usuario.getId(), request.getIdempotencyKey())
                    .map(this::compraToDTO)
                    .orElseThrow(() -> e);
        }
    }

    @Transactional
    public PagoPosicionamientoDTO registrarPagoPosicionamiento(Long eventoId, Long planId) {
        Usuario usuario = authHelper.usuarioAutenticado();
        Evento evento = eventoRepository.findById(eventoId)
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado"));
        var plan = planPromocionRepository.findById(planId)
                .filter(com.eventhive.app.model.PlanPromocion::isActivo)
                .orElseThrow(() -> new ResourceNotFoundException("Plan de promoción no encontrado o inactivo"));
        validarPropietarioPosicionamiento(evento, usuario);
        if (evento.getOrganizacion().getEstado() != EstadoOrganizacion.APROBADA
                || evento.getEstado() != EstadoEvento.PUBLICADO) {
            throw new BusinessException("Solo se puede pagar el posicionamiento de un evento publicado de una organización aprobada");
        }
        if (Boolean.TRUE.equals(evento.getPromocionado())
                || posicionamientoEventoRepository.existsByEventoIdAndEstadoIn(eventoId,
                        List.of(EstadoPosicionamiento.PENDIENTE, EstadoPosicionamiento.CONFIRMADO))) {
            throw new BusinessException("El evento ya tiene un posicionamiento activo o un pago pendiente");
        }

        PosicionamientoEvento pago = new PosicionamientoEvento();
        pago.setEvento(evento);
        pago.setOrganizador(usuario);
        pago.setPlan(plan);
        pago.setPrecio(plan.getPrecio());
        pago.setComisionPorcentaje(plan.getComisionPorcentaje());
        pago.setPlanPremium(plan.isPremium());
        pago.setPautaRedes(plan.isPautaRedes());
        pago.setMetodoPago("SIMULADO");
        pago.setEstado(EstadoPosicionamiento.PENDIENTE);
        return pagoPosicionamientoToDTO(posicionamientoEventoRepository.save(pago));
    }

    @Transactional(readOnly = true)
    public PagoPosicionamientoDTO obtenerPagoPosicionamiento(Long pagoId) {
        Usuario usuario = authHelper.usuarioAutenticado();
        PosicionamientoEvento pago = posicionamientoEventoRepository.findById(pagoId)
                .orElseThrow(() -> new ResourceNotFoundException("Pago de posicionamiento no encontrado"));
        validarPropietarioPosicionamiento(pago.getEvento(), usuario);
        return pagoPosicionamientoToDTO(pago);
    }

    @Transactional
    public PagoPosicionamientoDTO confirmarPagoPosicionamientoSimulado(Long pagoId) {
        Usuario usuario = authHelper.usuarioAutenticado();
        PosicionamientoEvento pago = posicionamientoEventoRepository.findById(pagoId)
                .orElseThrow(() -> new ResourceNotFoundException("Pago de posicionamiento no encontrado"));
        validarPropietarioPosicionamiento(pago.getEvento(), usuario);

        // Idempotencia: si ya está confirmado, retornar de forma consistente
        if (pago.getEstado() == EstadoPosicionamiento.CONFIRMADO) {
            return pagoPosicionamientoToDTO(pago);
        }

        if (pago.getEstado() != EstadoPosicionamiento.PENDIENTE) {
            throw new BusinessException("El pago ya no está pendiente");
        }
        pago.setEstado(EstadoPosicionamiento.CONFIRMADO);
        Evento evento = pago.getEvento();
        evento.setPromocionado(true);
        if (pago.getPlan() != null) {
            evento.setComisionPromocionPorcentaje(pago.getComisionPorcentaje());
        }
        // No se asigna foto a urlImagenDestacado automáticamente; Marketing es el encargado
        eventoRepository.save(evento);
        PosicionamientoEvento guardado = posicionamientoEventoRepository.save(pago);

        // Envío de correo sin interrumpir confirmación en caso de fallo SMTP
        try {
            serviceCorreo.enviarPromocionConfirmada(guardado);
        } catch (Exception ex) {
            // Un fallo de correo no revierte el pago confirmado
        }

        return pagoPosicionamientoToDTO(guardado);
    }

    @Transactional(readOnly = true)
    public void validarPagoPosicionamientoConfirmado(Long eventoId) {
        Usuario usuario = authHelper.usuarioAutenticado();
        Evento evento = eventoRepository.findById(eventoId)
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado"));
        validarPropietarioPosicionamiento(evento, usuario);
        if (!posicionamientoEventoRepository.existsByEventoIdAndEstado(
                eventoId, EstadoPosicionamiento.CONFIRMADO)) {
            throw new BusinessException("El pago de posicionamiento debe estar confirmado antes de destacar el evento");
        }
    }

    private void validarPropietarioPosicionamiento(Evento evento, Usuario usuario) {
        if (evento.getOrganizacion() == null || evento.getOrganizacion().getRepresentante() == null
                || !evento.getOrganizacion().getRepresentante().getId().equals(usuario.getId())) {
            throw new ResourceNotFoundException("Evento no encontrado");
        }
    }

    private PagoPosicionamientoDTO pagoPosicionamientoToDTO(PosicionamientoEvento pago) {
        return new PagoPosicionamientoDTO(pago.getId(), pago.getEvento().getId(),
                pago.getEvento().getOrganizacion().getId(), pago.getPrecio(), pago.getEstado());
    }


    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public Compra intentarCrearCompra(CompraRequestDTO request, Usuario usuario) {
        List<ItemCompra> items = new ArrayList<>();
        BigDecimal precioBaseTotal = BigDecimal.ZERO;
        Long eventoIdCompra = null;

        for (CompraRequestDTO.ItemRequest itemReq : request.getItems()) {
            Localidad localidad = buscarLocalidad(itemReq.getLocalidadId());
            validarEventoPublicado(localidad);
            Long eventoId = localidad.getEvento().getId();

            // Una compra solo puede incluir localidades del mismo evento.
            if (eventoIdCompra == null) {
                eventoIdCompra = eventoId;
            } else if (!eventoIdCompra.equals(eventoId)) {
                throw new BusinessException("Una compra solo puede contener entradas de un mismo evento");
            }

            descontarDisponibles(localidad, itemReq.getCantidad());
            BigDecimal precioBase = localidad.getPrecio();
            items.add(buildItem(localidad, itemReq.getCantidad(), precioBase));

            precioBaseTotal = precioBaseTotal.add(precioBase.multiply(BigDecimal.valueOf(itemReq.getCantidad())));
        }

        Evento evento = items.get(0).getEvento();

        // Fórmula: precio base = localidad, comisión comercial = base * porcentaje / 100
        // Total comprador = base + comisión comercial.
        // Neto organizador = base (no se le descuenta comisión al organizador).
        BigDecimal porcentajeComision = serviceMonetizacion.obtenerPorcentajeComision(evento);
        BigDecimal comisionEventhive = serviceMonetizacion.calcularComision(precioBaseTotal, porcentajeComision);
        BigDecimal netoOrganizador = serviceMonetizacion.calcularNetoOrganizador(precioBaseTotal);
        BigDecimal totalComprador = serviceMonetizacion.calcularTotalComprador(precioBaseTotal, comisionEventhive);

        Compra guardada = guardarCompra(usuario, items, totalComprador, porcentajeComision,
                comisionEventhive, netoOrganizador, request.getIdempotencyKey());

        generarTiquetes(items, guardada);
        return guardada;
    }

    @Transactional
    public void cancelarCompra(Long id) {
        Usuario usuario = authHelper.usuarioAutenticado();
        Compra compra = buscarCompra(id);
        validarOwnership(compra, usuario);
        validarCancelable(compra);

        int filasActualizadas = compraRepository.cancelarSiCancelable(
                compra.getId(),
                usuario.getId(),
                EstadoCompra.CANCELADA,
                List.of(EstadoCompra.PENDIENTE, EstadoCompra.CONFIRMADA));

        if (filasActualizadas == 0) {
            throw new BusinessException("La compra ya no puede cancelarse");
        }

        compra.getItems().forEach(item
                -> localidadRepository.incrementarDisponibles(
                item.getLocalidad().getId(), item.getCantidad()));

        // No se borra la compra ni los tiquetes: deben conservarse para
        // auditoría e histórico. Los tiquetes quedan asociados a una compra CANCELADA.
        compra.setEstado(EstadoCompra.CANCELADA);
        Compra guardada = compraRepository.save(compra);

        serviceNotification.notificarCompraCancelada(guardada);
    }

    // METODOS DE VALIDACION DE NEGOCIO
    private void validarEventoPublicado(Localidad localidad) {
        if (localidad.getEvento().getEstado() != EstadoEvento.PUBLICADO) {
            throw new BusinessException(
                    "No se pueden vender boletos para un evento que no está publicado");
        }
    }

    private void validarCancelable(Compra compra) {
        if (compra.getEstado() != EstadoCompra.PENDIENTE && compra.getEstado() != EstadoCompra.CONFIRMADA) {
            throw new BusinessException("La compra no se encuentra en un estado cancelable");
        }

        boolean eventoIniciado = compra.getItems().stream()
                .map(ItemCompra::getEvento)
                .anyMatch(this::yaComenzo);
        if (eventoIniciado) {
            throw new BusinessException("No es posible cancelar: el evento ya comenzó");
        }

        if (tiqueteRepository.existsByCompraIdAndUsadoTrue(compra.getId())) {
            throw new BusinessException("No es posible cancelar: existen tiquetes ya utilizados");
        }
    }

    private boolean yaComenzo(Evento evento) {
        return LocalDateTime.of(evento.getFecha(), evento.getHora()).isBefore(LocalDateTime.now());
    }

    private void validarRequest(CompraRequestDTO request) {

        if (request == null || request.getItems() == null || request.getItems().isEmpty()) {
            throw new BusinessException("Debe incluir al menos un ítem en la compra");
        }

        int totalBoletas = 0;

        for (CompraRequestDTO.ItemRequest item : request.getItems()) {
            if (item == null) {
                throw new BusinessException("El ítem de compra no puede ser nulo");
            }

            if (item.getLocalidadId() == null) {
                throw new BusinessException("La localidad es obligatoria");
            }

            if (item.getCantidad() == null || item.getCantidad() <= 0) {
                throw new BusinessException("La cantidad de entradas debe ser mayor que cero");
            }

            // Evita desbordamientos y rechaza el límite antes de sumar.
            if (item.getCantidad() > MAX_BOLETAS_POR_COMPRA - totalBoletas) {
                throw new BusinessException("No se pueden comprar más de 5 entradas por compra");
            }

            totalBoletas += item.getCantidad();
        }
    }

    //se deja en error 404 para no dar pista de que existen
    private void validarOwnership(Compra compra, Usuario usuario) {
        if (!compra.getCliente().getId().equals(usuario.getId())) {
            throw new ResourceNotFoundException("Compra no encontrada con id: ");
        }
    }

    private Compra buscarCompra(Long id) {
        return compraRepository.findByIdConItems(id)
                .orElseThrow(() -> new ResourceNotFoundException("Compra no encontrada con id: " + id));
    }

    private Localidad buscarLocalidad(Long localidadId) {
        return localidadRepository.findByIdConEvento(localidadId)
                .orElseThrow(() -> new ResourceNotFoundException("Localidad no encontrada: " + localidadId));
    }

    private void descontarDisponibles(Localidad localidad, Integer cantidad) {
        int filasAfectadas = localidadRepository.decrementarDisponibles(localidad.getId(), cantidad);
        if (filasAfectadas == 0) {
            throw new BusinessException(
                    "No hay suficientes entradas en '" + localidad.getNombre()
                            + "'. Disponibles: " + localidad.getDisponibles()
                            + ", solicitados: " + cantidad);
        }
    }

    //METODOS DE CREACION DE ENTIDADES
    private ItemCompra buildItem(Localidad localidad, Integer cantidad, BigDecimal precio) {
        ItemCompra item = new ItemCompra();
        item.setLocalidad(localidad);
        item.setEvento(localidad.getEvento());
        item.setCantidad(cantidad);
        item.setPrecioUnitario(precio);
        return item;
    }


    private Compra guardarCompra(Usuario usuario, List<ItemCompra> items, BigDecimal total,
                                 BigDecimal porcentajeComision, BigDecimal comisionEventhive,
                                 BigDecimal netoOrganizador, String idempotencyKey) {

        Compra compra = new Compra();

        compra.setIdempotencyKey(idempotencyKey);
        compra.setFechaCompra(LocalDateTime.now());
        compra.setTotal(total);

        compra.setPorcentajeComision(porcentajeComision);
        compra.setComisionEventhive(comisionEventhive);
        compra.setNetoOrganizador(netoOrganizador);

        compra.setMetodoPago("TARJETA");
        compra.setCliente(usuario);
        compra.setEstado(EstadoCompra.CONFIRMADA);

        items.forEach(item -> item.setCompra(compra));
        compra.setItems(items);

        return compraRepository.save(compra);
    }

    private void generarTiquetes(List<ItemCompra> items, Compra compra) {
        List<Tiquete> tiquetes = new ArrayList<>();

        for (ItemCompra item : items) {
            for (int i = 0; i < item.getCantidad(); i++) {
                Tiquete t = new Tiquete();
                t.setCodigoQR(UUID.randomUUID().toString());
                t.setLocalidad(item.getLocalidad());
                t.setEvento(item.getEvento());
                t.setCompra(compra);
                tiquetes.add(t);
            }
        }

        tiqueteRepository.saveAll(tiquetes);
    }

    // METODOS DE MAPEO
    private CompraResponseDTO compraToDTO(Compra compra) {
        return CompraResponseDTO.builder()
                .id(compra.getId())
                .fechaCompra(compra.getFechaCompra())
                .total(compra.getTotal())
                .comisionEventhive(compra.getComisionEventhive())
                .netoOrganizador(compra.getNetoOrganizador())
                .metodoPago(compra.getMetodoPago())
                .items(itemsToDTO(compra.getItems()))
                .build();
    }

    private List<ItemCompraDTO> itemsToDTO(List<ItemCompra> items) {
        if (items == null) {
            return List.of();
        }
        return items.stream().map(this::itemToDTO).toList();
    }

    private ItemCompraDTO itemToDTO(ItemCompra item) {
        return ItemCompraDTO.builder()
            .eventoId(item.getEvento().getId())
                .localidadId(item.getLocalidad().getId())
                .localidadNombre(item.getLocalidad().getNombre())
                .eventoNombre(item.getEvento().getTitulo())
                .cantidad(item.getCantidad())
                .precioUnitario(item.getPrecioUnitario())
                .subtotal(item.getPrecioUnitario()
                        .multiply(BigDecimal.valueOf(item.getCantidad())))
                .build();
    }
}