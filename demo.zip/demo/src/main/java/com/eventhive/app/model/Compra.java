package com.eventhive.app.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

import com.eventhive.app.enums.EstadoCompra;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name = "compras", indexes = {
    @Index(name = "idx_compra_cliente", columnList = "cliente_id"),
    @Index(name = "idx_compra_fecha", columnList = "fecha_compra"),
    @Index(name = "idx_compra_cliente_fecha", columnList = "cliente_id, fecha_compra")
}, uniqueConstraints = {
    @UniqueConstraint(name = "uk_compra_cliente_idempotency", columnNames = {"cliente_id", "idempotency_key"})
})
@Getter
@Setter
public class Compra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    //idempotencia: evitar q se haga la misma compra dos veces (única por cliente, ver uniqueConstraints)
    @Column(name = "idempotency_key", length = 100)
    private String idempotencyKey;

    @Column(name = "fecha_compra", nullable = false)
    private LocalDateTime fechaCompra;

    @Column(nullable = false, precision = 10, scale = 2)
    private BigDecimal total;

    @Column(name = "porcentaje_comision", nullable = false, precision = 5, scale = 2)
    private BigDecimal porcentajeComision = new BigDecimal("7.00");

    @Column(name = "comision_eventhive", nullable = false, precision = 12, scale = 2)
    private BigDecimal comisionEventhive = BigDecimal.ZERO;

    @Column(name = "neto_organizador", nullable = false, precision = 12, scale = 2)
    private BigDecimal netoOrganizador = BigDecimal.ZERO;

    @Column(name = "metodo_pago", length = 50)
    private String metodoPago;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EstadoCompra estado = EstadoCompra.PENDIENTE;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id", nullable = false)
    private Usuario cliente;

    @OneToMany(mappedBy = "compra", cascade = CascadeType.ALL, fetch = FetchType.LAZY, orphanRemoval = true)
    private List<ItemCompra> items;
}
