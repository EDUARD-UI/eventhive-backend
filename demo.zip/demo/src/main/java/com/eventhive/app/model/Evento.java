package com.eventhive.app.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.math.BigDecimal;
import java.util.List;

import com.eventhive.app.enums.EstadoEvento;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Index;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

import org.locationtech.jts.geom.Point;

@Entity
@Table(
        name = "eventos", indexes = {
        @Index(name = "idx_evento_organizacion", columnList = "organizacion_id"),
        @Index(name = "idx_evento_categoria", columnList = "categoria_id"),
        @Index(name = "idx_evento_estado", columnList = "estado"),
        @Index(name = "idx_evento_fecha", columnList = "fecha"),
        @Index(name = "idx_evento_fecha_creacion", columnList = "fecha_creacion")
})
@Getter
@Setter
public class Evento {//planes de promocionado

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 200)
    private String titulo;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @Column(length = 500)
    private String foto;

    @Column(nullable = false)
    private LocalDate fecha;

    @Column(nullable = false)
    private LocalTime hora;

    @Column(name = "fecha_creacion", nullable = false, updatable = false)
    private LocalDateTime fechaCreacion;

    @Column(length = 200)
    private String lugar;

    @Column(name = "ubicacion", columnDefinition = "geography(Point,4326)")
    private Point ubicacion;

    // URL del Codigo PULEP
    @Column(name = "url_pulep", length = 500)
    private String urlPulep;

    @Column(name = "url_imagen_destacado", length = 500)
    private String urlImagenDestacado;

    @Column(nullable = false)
    private Boolean promocionado = false;

    @Column(name = "comision_promocion_porcentaje", precision = 5, scale = 2)
    private BigDecimal comisionPromocionPorcentaje;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EstadoEvento estado = EstadoEvento.BORRADOR;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id", nullable = false)
    private Categoria categoria;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "organizacion_id", nullable = false)
    private Organizacion organizacion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "creado_por_id", nullable = false)
    private Usuario creadoPor;

    @OneToMany(mappedBy = "evento", cascade = CascadeType.ALL,
            orphanRemoval = true, fetch = FetchType.LAZY)
    private List<Localidad> localidades;

    @PrePersist
    private void prePersist() {

        if (fechaCreacion == null) {
            fechaCreacion = LocalDateTime.now();
        }

        if (estado == null) {
            estado = EstadoEvento.BORRADOR;
        }
    }
}