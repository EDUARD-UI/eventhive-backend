package com.eventhive.app.service;

import com.eventhive.app.repository.TiqueteRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.eventhive.app.dto.response.ValoracionDTO;
import com.eventhive.app.exception.BusinessException;
import com.eventhive.app.exception.ResourceNotFoundException;
import com.eventhive.app.model.Organizacion;
import com.eventhive.app.model.Usuario;
import com.eventhive.app.model.Valoracion;
import com.eventhive.app.repository.OrganizacionRepository;
import com.eventhive.app.repository.ValoracionRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ServiceValoracion {

    private final ValoracionRepository valoracionRepository;
    private final OrganizacionRepository organizacionRepository;
    private final TiqueteRepository tiqueteRepository;
    private final ServiceOrganizacion serviceOrganizacion;

    //CONSULTAS
    @Transactional(readOnly = true)
    public Page<ValoracionDTO> obtenerValoracionesDTOPorUsuario(Long usuarioId, Pageable pageable) {
        return valoracionRepository.findByClienteIdConOrganizacion(usuarioId, pageable).map(this::toDTO);
    }

    @Transactional(readOnly = true)
    public Page<ValoracionDTO> obtenerValoracionesDTOPorOrganizacion(Long organizacionId, Pageable pageable) {
        return valoracionRepository.findByOrganizacionIdConCliente(organizacionId, pageable).map(this::toDTO);
    }

    //OPERACIONES DE VALORACION
    @Transactional
    public void crearValoracion(Usuario usuario, Long organizacionId, String comentario, long calificacion) {

        Organizacion organizacion = organizacionRepository.findById(organizacionId)
                .orElseThrow(() -> new ResourceNotFoundException("Organización no encontrada"));

        validarNoEsMiOrganizacion(usuario, organizacion);
        validarCalificacion(calificacion);

        if (!tiqueteRepository.existsCompraConfirmadaPorClienteYOrganizacion(
                usuario.getId(),
                organizacionId)) {

            throw new BusinessException(
                    "Solo puedes valorar una organización, si has comprado al menos un boleto de ella");
        }

        Valoracion v = valoracionRepository.findByClienteIdAndOrganizacionId(usuario.getId(), organizacionId)
                .orElse(null);

        if (v == null) {
            v = new Valoracion();
            v.setCliente(usuario);
            v.setOrganizacion(organizacion);
        }

        v.setComentario(comentario);
        v.setCalificacion((int) calificacion);
        valoracionRepository.save(v);

        serviceOrganizacion.actualizarMetricasValoracion(organizacionId);
    }

    @Transactional
    public void actualizarValoracion(Long id, Usuario usuario, String comentario, long calificacion) {
        validarCalificacion(calificacion);
        Valoracion v = obtenerVerificada(id, usuario);
        Long organizacionId = v.getOrganizacion().getId();

        v.setComentario(comentario);
        v.setCalificacion((int) calificacion);
        valoracionRepository.save(v);

        serviceOrganizacion.actualizarMetricasValoracion(organizacionId);
    }

    @Transactional
    public void eliminarValoracion(Long id, Usuario usuario) {
        Valoracion v = obtenerVerificada(id, usuario);
        Long organizacionId = v.getOrganizacion().getId();

        valoracionRepository.deleteById(id);

        serviceOrganizacion.actualizarMetricasValoracion(organizacionId);
    }

    // METODOS AUXILIARES Y DE MAPEO
    private Valoracion obtenerVerificada(Long id, Usuario usuario) {
        Valoracion v = valoracionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Valoración no encontrada"));
        if (!v.getCliente().getId().equals(usuario.getId())) {
            throw new BusinessException("No autorizado para modificar esta valoración");
        }
        return v;
    }

    private void validarCalificacion(long c) {
        if (c < 1 || c > 5) {
            throw new BusinessException("La calificación debe estar entre 1 y 5");
        }
    }

    private void validarNoEsMiOrganizacion(Usuario usuario, Organizacion organizacion) {
        if (organizacion == null || usuario == null || usuario.getOrganizacion() == null) {
            return;
        }

        boolean esMiOrganizacion = organizacion.getId() != null
                && organizacion.getId().equals(usuario.getOrganizacion().getId());

        if (esMiOrganizacion) {
            throw new BusinessException("No puedes valorar a la organización a la que perteneces");
        }
    }

    private ValoracionDTO toDTO(Valoracion v) {
        ValoracionDTO dto = new ValoracionDTO();
        dto.setId(v.getId());
        dto.setComentario(v.getComentario());
        dto.setCalificacion(v.getCalificacion());

        if (v.getCliente() != null) {
            dto.setClienteId(v.getCliente().getId());
            dto.setClienteNombre(v.getCliente().getNombreCompleto());
        }

        if (v.getOrganizacion() != null) {
            dto.setOrganizacionId(v.getOrganizacion().getId());
            dto.setOrganizacionNombre(v.getOrganizacion().getRazonSocial());
        }
        return dto;
    }
}
