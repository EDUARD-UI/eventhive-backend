package com.eventhive.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.eventhive.app.model.Localidad;

public interface LocalidadRepository extends JpaRepository<Localidad, Long> {

    // Busca todas las localidades asociadas a un evento
    List<Localidad> findByEventoId(Long eventoId);

    long countByEventoId(Long eventoId);

    // Decrementa las localidades disponibles
    @Modifying
    @Query("UPDATE Localidad l SET l.disponibles = l.disponibles - :cantidad WHERE l.id = :id AND l.disponibles >= :cantidad")
    int decrementarDisponibles(@Param("id") Long id, @Param("cantidad") int cantidad);

    // Incrementa las localidades disponibles
    @Modifying
    @Query("UPDATE Localidad l SET l.disponibles = l.disponibles + :cantidad WHERE l.id = :id")
    void incrementarDisponibles(@Param("id") Long id, @Param("cantidad") int cantidad);

    // Busca todas las localidades de una lista de eventos
    List<Localidad> findByEventoIdIn(List<Long> eventoIds);

    // Busca una localidad con su evento y organización cargados
    @Query("SELECT l FROM Localidad l JOIN FETCH l.evento e JOIN FETCH e.organizacion WHERE l.id = :id")
    java.util.Optional<com.eventhive.app.model.Localidad> findByIdConEvento(@Param("id") Long id);
}