package com.eventhive.app.repository;

import com.eventhive.app.model.Usuario;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    // Busca un usuario por correo
    Optional<Usuario> findByCorreo(String correo);

    Optional<Usuario> findByCorreoIgnoreCase(String correo);

    boolean existsByCorreoIgnoreCase(String correo);

    // Verifica si existe un usuario con ese correo
    boolean existsByCorreo(String correo);

    // Busca usuarios por nombre de rol (paginado, para pantallas administrativas)
    Page<Usuario> findByRolNombre(String nombre, Pageable pageable);

    // Moderadores paginados con el rol ya cargado (el mapeo a DTO ocurre fuera de la sesión)
    @Query(value = "SELECT u FROM Usuario u JOIN FETCH u.rol r WHERE r.nombre = :nombre ORDER BY u.nombreCompleto ASC",
           countQuery = "SELECT COUNT(u) FROM Usuario u WHERE u.rol.nombre = :nombre")
    Page<Usuario> findByRolNombreConRol(@Param("nombre") String nombre, Pageable pageable);

    // Lista COMPLETA de usuarios por rol, sin paginar (uso interno: notificaciones a moderadores)
    List<Usuario> findAllByRolNombre(String nombre);

    // Busca un usuario por id con su rol cargado
    @Query("SELECT u FROM Usuario u JOIN FETCH u.rol LEFT JOIN FETCH u.organizacion WHERE u.id = :id")
    Optional<Usuario> findByIdConRol(@Param("id") Long id);

    // Obtiene todos los usuarios con su rol cargado
    @Query(value = "SELECT u FROM Usuario u JOIN FETCH u.rol LEFT JOIN FETCH u.organizacion",
           countQuery = "SELECT COUNT(u) FROM Usuario u")
    Page<Usuario> findAllConRol(Pageable pageable);

    // Busca un usuario por correo con su rol cargado
    @Query("SELECT u FROM Usuario u JOIN FETCH u.rol WHERE u.correo = :correo")
    Optional<Usuario> findByCorreoConRol(@Param("correo") String correo);

    // Usuario autenticado listo para la logica de negocio: rol, organizacion (con su
    // representante) y permisos de evento ya inicializados, para poder usarlo fuera de
    // una sesion de Hibernate sin LazyInitializationException.
    @Query("""
        SELECT u FROM Usuario u
        JOIN FETCH u.rol
        LEFT JOIN FETCH u.organizacion o
        LEFT JOIN FETCH o.representante
        LEFT JOIN FETCH u.permisosEvento
        WHERE u.correo = :correo
        """)
    Optional<Usuario> findByCorreoConContexto(@Param("correo") String correo);

    // Busca usuarios por rol
    @Query(value = "SELECT u FROM Usuario u JOIN FETCH u.rol r LEFT JOIN FETCH u.organizacion WHERE r.id = :rolId",
           countQuery = "SELECT COUNT(u) FROM Usuario u WHERE u.rol.id = :rolId")
    Page<Usuario> findByRolId(@Param("rolId") Long rolId, Pageable pageable);

    // Busca usuarios cuyo nombre contiene el texto indicado
    @Query(value = "SELECT u FROM Usuario u JOIN FETCH u.rol LEFT JOIN FETCH u.organizacion WHERE LOWER(u.nombreCompleto) LIKE LOWER(CONCAT('%', :nombre, '%'))",
           countQuery = "SELECT COUNT(u) FROM Usuario u WHERE LOWER(u.nombreCompleto) LIKE LOWER(CONCAT('%', :nombre, '%'))")
    Page<Usuario> findByNombreContieneIgnoreCase(@Param("nombre") String nombre, Pageable pageable);

    // Cuenta usuarios por rol
    @Query("SELECT COUNT(u) FROM Usuario u WHERE u.rol.id = :rolId")
    long countByRolId(@Param("rolId") Long rolId);

    // Busca usuarios por nombre y rol
    @Query(value = """
        SELECT u FROM Usuario u JOIN FETCH u.rol r LEFT JOIN FETCH u.organizacion
        WHERE LOWER(u.nombreCompleto) LIKE LOWER(CONCAT('%', :nombre, '%'))
        AND r.id = :rolId
        """,
        countQuery = """
        SELECT COUNT(u) FROM Usuario u
        WHERE LOWER(u.nombreCompleto) LIKE LOWER(CONCAT('%', :nombre, '%'))
        AND u.rol.id = :rolId
        """)
    Page<Usuario> findByNombreYRolId(@Param("nombre") String nombre,
                                     @Param("rolId")   Long rolId,
                                     Pageable pageable);

    // Lista los operadores de una organizacion
    @Query(value = """
    SELECT u FROM Usuario u
    JOIN FETCH u.rol r
    WHERE u.organizacion.id = :organizacionId
      AND UPPER(r.nombre) = 'OPERADOR'
    ORDER BY u.nombreCompleto ASC
    """,
    countQuery = """
    SELECT COUNT(u) FROM Usuario u
    WHERE u.organizacion.id = :organizacionId
      AND UPPER(u.rol.nombre) = 'OPERADOR'
    """)
    Page<Usuario> findOperadoresByOrganizacionId(
            @Param("organizacionId") Long organizacionId,
            Pageable pageable);
}