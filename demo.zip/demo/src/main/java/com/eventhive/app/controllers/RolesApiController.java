package com.eventhive.app.controllers;

import com.eventhive.app.dto.request.RolRequest;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.eventhive.app.dto.ApiResponse;
import com.eventhive.app.dto.PagedResponse;
import com.eventhive.app.dto.response.RolDTO;
import com.eventhive.app.model.Rol;
import com.eventhive.app.service.ServiceRoles;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/roles")
public class RolesApiController {

    private final ServiceRoles serviceRoles;

    @GetMapping
    public ResponseEntity<ApiResponse<PagedResponse<RolDTO>>> listarRoles(Pageable pageable) {
        Page<RolDTO> page = serviceRoles.obtenerTodosRoles(pageable).map(serviceRoles::toDTO);
        PagedResponse<RolDTO> response = new PagedResponse<>(
            page.getContent(),
            page.getNumber(),
            page.getSize(),
            page.getTotalElements(),
            page.getTotalPages()
        );
        return ResponseEntity.ok(ApiResponse.ok("Roles obtenidos", response));
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public ResponseEntity<ApiResponse<Void>> crearRol(
            @Valid @RequestBody RolRequest rolRequest) {

        serviceRoles.crearRol(rolRequest.getNombre());
        return ResponseEntity.status(HttpStatus.CREATED).body(ApiResponse.ok("Rol creado exitosamente"));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public ResponseEntity<ApiResponse<Void>> actualizarRol(
            @PathVariable Long id,
            @RequestParam String nombre) {

        serviceRoles.actualizarRol(id, nombre);
        return ResponseEntity.ok(ApiResponse.ok("Rol actualizado exitosamente"));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMINISTRADOR')")
    public ResponseEntity<ApiResponse<Void>> eliminarRol(@PathVariable Long id) {
        serviceRoles.eliminarRol(id);
        return ResponseEntity.ok(ApiResponse.ok("Rol eliminado exitosamente"));
    }
}
