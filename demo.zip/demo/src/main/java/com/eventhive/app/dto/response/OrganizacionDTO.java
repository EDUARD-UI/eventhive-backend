package com.eventhive.app.dto.response;

import java.time.LocalDateTime;

import com.eventhive.app.enums.EstadoOrganizacion;
import com.eventhive.app.enums.NivelOrganizador;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizacionDTO {

    private Long id;

    // Datos legales
    private String representante;
    private String representanteCorreo;
    private String razonSocial;
    private String nit;
    private String correoContacto;
    private String descripcion;
    private String urlLogo;
    private LocalDateTime fechaCreacion;

    public String getImagenPerfil() {
        return urlLogo;
    }

    public Double getReputacion() {
        return promedioRating;
    }

    // Estadísticas
    private Double promedioRating;
    private Integer totalValoraciones;
    private Integer totalSeguidores;
    private Integer totalEventosCreados;
    private Long eventosActivos;
    private Integer eventosFinalizados;
    private Integer eventosRechazados;
    private NivelOrganizador nivel;
    private EstadoOrganizacion estado;

    // Información de verificación y RUT
    private String estadoValidacionRut;
    private String urlRutTemporal;
}
