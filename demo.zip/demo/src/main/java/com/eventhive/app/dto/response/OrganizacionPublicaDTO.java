package com.eventhive.app.dto.response;

import java.time.LocalDateTime;

import com.eventhive.app.enums.EstadoOrganizacion;
import com.eventhive.app.enums.NivelOrganizador;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrganizacionPublicaDTO {
    private Long id;
    private String razonSocial;
    private String representante;
    private String descripcion;
    private String urlLogo;
    private LocalDateTime fechaCreacion;

    public String getImagenPerfil() {
        return urlLogo;
    }

    public Double getReputacion() {
        return promedioRating;
    }
    private Double promedioRating;
    private Integer totalValoraciones;
    private Integer totalSeguidores;
    private Integer totalEventosCreados;
    private Long eventosActivos;
    private NivelOrganizador nivel;
    private EstadoOrganizacion estado;
}